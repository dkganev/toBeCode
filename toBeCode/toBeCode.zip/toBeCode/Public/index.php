<?php
    require_once "../App/Controllers/Products.php";

    use Controllers\Products;

    
    
    //routing
    $products = new Products();
    $products->Index();
















?>