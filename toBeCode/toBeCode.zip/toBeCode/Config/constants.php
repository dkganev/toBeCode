<?php

define('BASE_PATH', dirname(dirname(dirname(__FILE__))) . '/toBeCode'  );
define('API_CONFIG_PATH', BASE_PATH.'/Config');
define('API_CONFIG_File', BASE_PATH.'/Config/config.ini');
define('API_INIT_File', BASE_PATH.'/Config/Init.php');

?>